//
//  UXCamConfiguration.h
//  UXCam
//
//  Created by Ankit Karna on 25/08/2021.
//  Copyright © 2021 UXCam. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UXCam/UXCamOcclusion.h>

typedef NS_ENUM(NSInteger, UXEnvironment) {
    UXEnvironmentAlpha = 1, //Debug build while developing on Xcode
    UXEnvironmentBeta = 2, //Release build but app not installed from app store rather TestFlight
    UXEnvironmentRelease = 3 //Release build when app installed from app store (Default)
};

NS_ASSUME_NONNULL_BEGIN

@interface UXCamConfiguration : NSObject

/**
 *  @brief AppKey for the current UXCam user
 */
@property (strong, nonatomic, readonly) NSString *userAppKey;

/**
 *  @brief Set this to true before calling startWithKey to enable UXCam from capturing verbose/Integration log.
 *
 *  NO to disable integration logging
 *  @note By default integration logging is disabled, with it disabled then logging about various integration will be unseen in console
 */
@property (nonatomic, assign) BOOL enableIntegrationLogging;

/**
 *	Set whether to record multiple sessions or not
 *
 *  YES to record a new session automatically when the device comes out of the background. If NO then a single session is recorded, when stopped (either programmatically with @c stopApplicationAndUploadData or by the app going to the background) then no more sessions are recorded until @c startWithConfiguration is called again).
 *  @note The default setting is to record a new session each time a device comes out of the background. This flag can be set to NO to stop that.
 */
@property (nonatomic, assign) BOOL enableMultiSessionRecord;

/**
 *  @brief Set this to false before calling startWithKey to disable UXCam from capturing crashed sessions
 *
 *  NO to disable crash capture
 *  @note By default crashhandling is enabled, with it disabled then sessions that crash will be lost
 */
@property (nonatomic, assign) BOOL enableCrashHandling;

/**
 *	@brief Enable / disable the automatic tagging of screen names
 *
 *	By default UXCam will tag new screen names automatically. You can override this using the @c tagScreenName: method, or use this property to disable the automatic tagging. Build a list of screen names to ignore with the @c addScreenNamesToIgnore: method
 *
 *	Set to TRUE to enable automatic screen name tagging (the default) or FALSE to disable it
 */
@property (nonatomic, assign) BOOL enableAutomaticScreenNameTagging;

/**
 * Control the gesture recognizers used by UXCam
 * TRUE to enable the full range of gesture recognizers (the default), or FALSE to limit it to basic touches
 * @note Disabling the advanced gesture recognizers (swipes, zoom etc.) can be useful if you have another SDK integrated that doesn't cooperate properly with gesture recognizers installed in other views.
 */
@property (nonatomic, assign) BOOL enableAdvancedGestureRecognition;

/**
 * @brief Enable latest screen recording apis to capture screens.
 * TRUE to enable the view based rendering  (the default), or FALSE to use layer based screen rendering methods
 * @note Disable this property in case the performance has degraded after using UXCam, but this might not render complex screens effectively
 */
@property (nonatomic, assign) BOOL enableImprovedScreenCapture;

/**
 *  Set this property to capture network logs.
 *  This will control the capture of summary logs about the applications network activity. By default this is disabled.
 *
 *  @brief Enable or disable capturing logs of network activity
 *  YES to enable capturing logs. If NO, UXCam will not capture any network logs until it is set to YES again.
 */
@property (nonatomic, assign) BOOL enableNetworkLogging;

@property (nullable, nonatomic, strong) UXCamOcclusion *occlusion;

/**
 *  Set this property to emulate app run in desired environment with respective configurations.
 *  This will run app in the desired environment overriding the current environment. By default this lets app run in the current environment.
 *
 *  .alpha → Debug build while developing on Xcode
    .beta → Release build but app not installed from app store rather TestFlight
    .release → Release build when app installed from app store (Default)
 *
 */
@property (nonatomic) UXEnvironment environment;

/**
 * Set this property to bundle identifiers of third party frameworks for screens that you want to capture.
 * @note You don't need to set this value if all your screens are in `NSBundle.mainBundle`.
 */
@property (strong, nonatomic) NSArray<NSString *> *frameworksBundleIdentifiers;

/**
 *	@brief Designated initializer for the configuration object
 *  @param userAppKey    The key to identify your UXCam account - find it in the UXCam dashboard for your account at https://dashboard.uxcam.com/user/settings
 */
- (instancetype)initWithAppKey:(NSString *)userAppKey NS_DESIGNATED_INITIALIZER;

/**
 * Use  `initWithAppKey` to create a configuration instance
 */
- (instancetype)init NS_UNAVAILABLE;

@end

NS_ASSUME_NONNULL_END
