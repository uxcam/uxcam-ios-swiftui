//
//  UXCamSwiftUI.h
//  UXCamSwiftUI
//
//  Created by Richard Groves on 08/09/2021.
//

#import <Foundation/Foundation.h>

//! Project version number for UXCamSwiftUI.
FOUNDATION_EXPORT double UXCamSwiftUIVersionNumber;

//! Project version string for UXCamSwiftUI.
FOUNDATION_EXPORT const unsigned char UXCamSwiftUIVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <UXCamSwiftUIKit/PublicHeader.h>


